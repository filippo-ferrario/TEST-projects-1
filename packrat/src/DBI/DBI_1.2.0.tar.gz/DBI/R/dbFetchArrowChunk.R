#' @rdname dbFetch
#' @export
setGeneric("dbFetchArrowChunk",
  def = function(res, ...) standardGeneric("dbFetchArrowChunk")
)
