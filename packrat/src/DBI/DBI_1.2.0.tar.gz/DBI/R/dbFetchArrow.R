#' @rdname dbFetch
#' @export
setGeneric("dbFetchArrow",
  def = function(res, ...) standardGeneric("dbFetchArrow")
)
