setGeneric("dbiDataType",
  def = function(x, ...) standardGeneric("dbiDataType")
)
