#' @name dbWriteTable
#' @aliases dbWriteTableArrow
#' @export
setGeneric("dbWriteTableArrow",
  def = function(conn, name, value, ...) standardGeneric("dbWriteTableArrow")
)
