#' @name dbAppendTable
#' @aliases dbAppendTableArrow
#' @export
setGeneric("dbAppendTableArrow",
  def = function(conn, name, value, ...) standardGeneric("dbAppendTableArrow")
)
