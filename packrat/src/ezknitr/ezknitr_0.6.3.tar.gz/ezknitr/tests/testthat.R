library(testthat)
library(ezknitr)

test_check("ezknitr")
